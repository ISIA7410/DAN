# python_dinosaur_game
dinosaur game, python, pygame.

simple dinosaur game with python, pygame.

blog : https://blockdmask.tistory.com/419

youtube : https://youtu.be/ok_8mvQ8CiY
